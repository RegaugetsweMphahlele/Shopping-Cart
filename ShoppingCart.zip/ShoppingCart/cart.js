


//Open and Close cart
const cartIcon = document.querySelector("#cart-icon");
const cart = document.querySelector(".cart");
const closeCart = document.querySelector("#cart-close");

cartIcon.addEventListener("click", () => {
    cart.classList.add("active");
});

closeCart.addEventListener("click", () => {
    cart.classList.remove("active");
});

document.getElementById('addItem').addEventListener('click', function() {
    var totalPriceElement = document.getElementById('totalPrice');
    var currentTotal = parseInt(totalPriceElement.textContent.replace('R', ''));
    var priceToAdd = 500; // Price of the item to add

    var newTotal = currentTotal + priceToAdd;
    totalPriceElement.textContent = 'R' + newTotal;
});